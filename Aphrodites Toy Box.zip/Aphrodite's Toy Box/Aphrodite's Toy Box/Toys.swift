//
//  Toys.swift
//  Aphrodite's Toy Box
//
//  Created by Jessica Alexander on 6/4/19.
//  Copyright © 2019 Jessica Alexander. All rights reserved.
//

import Foundation
import UIKit

struct Toys{
    var name = ""
    var description = ""
    var image = UIImage(named: "")
}
