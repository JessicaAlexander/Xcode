//
//  Goblins.swift
//  DragonsGoblinsElves
//
//  Created by Jessica Alexander on 7/30/19.
//  Copyright © 2019 Jessica Alexander. All rights reserved.
//

import Foundation
import UIKit

struct Goblins {
    var name = ""
    var description = ""
    var image = UIImage(named: "")
}
