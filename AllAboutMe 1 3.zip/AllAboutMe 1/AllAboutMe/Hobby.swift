//
//  Hobby.swift
//  AllAboutMe
//
//  Created by Jessica Alexander on 6/25/19.
//  Copyright © 2019 Jessica Alexander. All rights reserved.
//

import Foundation
import UIKit

struct Hobby {
    var title = ""
    var description = ""
    var ImageName:UIImage?
    
}
